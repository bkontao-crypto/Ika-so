package com.ikaso.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.webkit.*
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.snackbar.Snackbar
import com.ikaso.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var ui: ActivityMainBinding
    val web: WebView get() = ui.web
    private val handler = Handler(Looper.getMainLooper())
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null
    private var pendingGeo: Pair<String, GeolocationPermissions.Callback>? = null
    private var lastBackPress = 0L
    private var failed = false
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var backgroundedAt = 0L
    private var locked = false
    private var masking = false                  // voile affiché pendant un rechargement / retour à l'accueil
    private var revealToTop = true               // à la fin du chargement, remettre la page tout en haut
    private var clearHistoryPending = false      // après un retour à l'accueil : vider l'historique (Retour ne ramène pas à l'ancienne page)
    private var skipResetOnce = false            // sortie « normale » (sélecteur de photo, lien de retour) : ne pas revenir à l'accueil
    private var readyPoll: Runnable? = null
    private val coverFailsafe = Runnable { hideCover() }
    @Volatile var refreshBlocked = false          // renseigné par le site au toucher (voir INJECT_JS)
    private val host: String = BuildConfig.SITE_HOST

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); fileCallback = null
    }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        pendingPermissionRequest?.let { if (ok) it.grant(it.resources) else it.deny() }; pendingPermissionRequest = null
    }
    private val locPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        pendingGeo?.let { (o, cb) -> cb.invoke(o, r.values.any { it }, false) }; pendingGeo = null
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        ViewCompat.setOnApplyWindowInsetsListener(ui.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom)); WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, ui.root).apply { isAppearanceLightNavigationBars = true; isAppearanceLightStatusBars = true }

        with(ui.web.settings) {
            javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true; loadWithOverviewMode = false
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            textZoom = 100
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false; allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)      // target="_blank" (WhatsApp…) intercepté dans onCreateWindow
            userAgentString = "$userAgentString IkaSoApp/${BuildConfig.VERSION_NAME}"
        }
        ui.web.setBackgroundColor(ContextCompat.getColor(this, R.color.surface))
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(ui.web, false) }   // session du site = cookie
        ui.web.addJavascriptInterface(AppBridge(this), "AndroidBridge")

        ui.web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String, favicon: Bitmap?) {
                failed = false; ui.progress.visibility = View.VISIBLE
                if (masking && revealToTop) v.scrollTo(0, 0)      // rechargement / accueil : toujours en haut
                handler.removeCallbacks(wakingHint); handler.postDelayed(wakingHint, 8000)
            }
            override fun onPageFinished(v: WebView, url: String) {
                handler.removeCallbacks(wakingHint); ui.waking.visibility = View.GONE
                ui.progress.visibility = View.GONE; ui.swipe.isRefreshing = false
                if (!failed) {
                    ui.offline.visibility = View.GONE
                    v.evaluateJavascript(TRACK_JS, null); v.evaluateJavascript(INJECT_JS, null)
                    if (clearHistoryPending) { v.clearHistory(); clearHistoryPending = false }
                    if (masking) revealWhenReady()          // le voile reste tant que le contenu de la page n'est pas affiché
                } else hideCover()
                CookieManager.getInstance().flush()
            }
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (u.scheme == "https" && u.host == host) return false
                openExternal(u); return true          // WhatsApp, appel, e-mail, page de paiement, autres sites
            }
            override fun onReceivedError(v: WebView, req: WebResourceRequest, err: WebResourceError) {
                if (req.isForMainFrame) { failed = true; ui.offline.visibility = View.VISIBLE; hideCover() }
            }
            override fun onReceivedHttpError(v: WebView, req: WebResourceRequest, resp: WebResourceResponse) {
                if (req.isForMainFrame && resp.statusCode >= 500) { failed = true; ui.offline.visibility = View.VISIBLE; hideCover() }
            }
            override fun onRenderProcessGone(v: WebView, detail: RenderProcessGoneDetail): Boolean { v.reload(); return true }
        }
        ui.web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { ui.progress.setProgressCompat(p, true) }
            // Photos des annonces, pièces justificatives…
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = cb
                skipResetOnce = true      // photo / document / caméra : on revient au formulaire, même après plus de 30 s
                return try { filePicker.launch(p.createIntent()); true } catch (e: ActivityNotFoundException) { fileCallback = null; skipResetOnce = false; false }
            }
            // Géolocalisation (« près de moi », carte) : uniquement pour le site de l'application
            override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                val granted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                when {
                    Uri.parse(origin).host != host -> cb.invoke(origin, false, false)
                    granted -> cb.invoke(origin, true, false)
                    else -> { pendingGeo = origin to cb; locPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }
                }
            }
            override fun onPermissionRequest(req: PermissionRequest) {
                if (req.origin.host == host && req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                    pendingPermissionRequest = req; cameraPermission.launch(Manifest.permission.CAMERA)
                } else req.deny()
            }
            // target="_blank" : même site → dans l'application (avec la session) ; sinon application externe (WhatsApp, e-mail…)
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val temp = WebView(view.context)
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        if (r.url.scheme == "https" && r.url.host == host) view.loadUrl(r.url.toString()) else openExternal(r.url)
                        v.destroy(); return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = temp; resultMsg.sendToTarget(); return true
            }
        }
        ui.web.setDownloadListener { url, ua, disposition, mime, _ -> download(url, ua, disposition, mime) }

        ui.swipe.setColorSchemeResources(R.color.brand)
        ui.swipe.setOnRefreshListener {
            // garde-fou : demander confirmation seulement si l'utilisateur a réellement saisi du texte non enregistré
            ui.web.evaluateJavascript(DIRTY_JS) { r ->
                ui.swipe.isRefreshing = false
                if (r == "true") {
                    MaterialAlertDialogBuilder(this).setTitle("Actualiser la page ?").setMessage("Les données saisies et non enregistrées seront perdues.")
                        .setPositiveButton("Actualiser") { _, _ -> refreshPage() }.setNegativeButton("Annuler", null).show()
                } else refreshPage()
            }
        }
        ui.swipe.setOnChildScrollUpCallback { _, _ -> ui.web.scrollY > 0 || refreshBlocked }
        ui.retry.setOnClickListener { ui.offline.visibility = View.GONE; failed = false; showCover(true); ui.web.loadUrl(BuildConfig.BASE_URL) }
        ui.unlock.setOnClickListener { promptUnlock() }
        ui.quit.setOnClickListener { finishAffinity() }

        netCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) { if (failed) runOnUiThread { ui.retry.performClick() } }
        }
        (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).registerDefaultNetworkCallback(netCallback!!)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (locked) { finishAffinity(); return }
                if (ui.web.canGoBack()) ui.web.goBack()
                else {
                    val now = System.currentTimeMillis()
                    if (now - lastBackPress < 2000) finish() else { lastBackPress = now; toast(getString(R.string.press_again)) }
                }
            }
        })

        // Script exécuté avant le site à chaque chargement : suit les requêtes en cours pour savoir quand la page est vraiment affichée
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(ui.web, DOC_START_JS + TRACK_JS, setOf("https://$host"))
        }
        val start = intent?.data?.takeIf { it.host == host }?.toString() ?: BuildConfig.BASE_URL
        // Mémoire de 30 s : si l'application a été arrêtée par le système, on ne restaure la page que si l'absence a duré moins de 30 s
        val within30s = System.currentTimeMillis() - Prefs.leftAt(this) <= RESET_AFTER_MS
        if (savedInstanceState != null && within30s) {
            showCover(false)
            if (ui.web.restoreState(savedInstanceState) == null) { showCover(true); ui.web.loadUrl(start) }
        } else {
            showCover(true)
            ui.web.loadUrl(if (savedInstanceState == null) start else BuildConfig.BASE_URL)
        }
        if (intent?.action == ACTION_SETTINGS) ui.web.post { showSettings() }
        lockIfNeeded()
    }

    private val wakingHint = Runnable { ui.waking.visibility = View.VISIBLE }

    // ---------- Verrouillage empreinte / code ----------
    private fun lockIfNeeded() {
        if (!Prefs.lockEnabled(this) || locked) return
        val can = BiometricManager.from(this).canAuthenticate(BIOMETRIC_WEAK or DEVICE_CREDENTIAL)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) return      // aucun verrouillage d'écran sur le téléphone : rien à demander
        locked = true; ui.lock.visibility = View.VISIBLE; promptUnlock()
    }
    private fun promptUnlock() {
        val info = BiometricPrompt.PromptInfo.Builder().setTitle(getString(R.string.app_name)).setSubtitle("Déverrouillez pour continuer")
            .setAllowedAuthenticators(BIOMETRIC_WEAK or DEVICE_CREDENTIAL).build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { locked = false; ui.lock.visibility = View.GONE }
        }).authenticate(info)
    }
    override fun onStop() {
        backgroundedAt = System.currentTimeMillis(); Prefs.setLeftAt(this, backgroundedAt); super.onStop()
    }
    override fun onStart() {
        super.onStart()
        if (backgroundedAt > 0) {
            val away = System.currentTimeMillis() - backgroundedAt
            // Moins de 30 s dehors : le site reprend exactement où l'utilisateur l'a laissé.
            // Plus de 30 s : la mémoire est réinitialisée et l'utilisateur revient directement à l'accueil.
            if (skipResetOnce) skipResetOnce = false else if (away > RESET_AFTER_MS) goHome()
            if (away > 60_000) lockIfNeeded()          // reverrouillage après 1 min en arrière-plan
        }
        backgroundedAt = 0
    }

    // ---------- Voile de chargement, actualisation, retour à l'accueil ----------
    private fun showCover(toTop: Boolean) {
        masking = true; revealToTop = toTop
        ui.cover.animate().cancel(); ui.cover.alpha = 1f; ui.cover.visibility = View.VISIBLE
        handler.removeCallbacks(coverFailsafe); handler.postDelayed(coverFailsafe, 60_000)
    }
    private fun hideCover() {
        masking = false
        readyPoll?.let { handler.removeCallbacks(it) }; readyPoll = null
        handler.removeCallbacks(coverFailsafe)
        if (ui.cover.visibility != View.VISIBLE) return
        ui.cover.animate().alpha(0f).setDuration(160).withEndAction { ui.cover.visibility = View.GONE }.start()
    }
    /** Attend que la page ait fini de charger ET d'afficher son contenu, puis remonte en haut et retire le voile. */
    private fun revealWhenReady() {
        readyPoll?.let { handler.removeCallbacks(it) }
        val t0 = System.currentTimeMillis()
        val poll = object : Runnable {
            override fun run() {
                ui.web.evaluateJavascript(READY_JS) { res ->
                    if (res == "true" || System.currentTimeMillis() - t0 > MAX_WAIT_MS) {
                        if (revealToTop) { ui.web.scrollTo(0, 0); ui.web.evaluateJavascript("window.scrollTo(0,0)", null) }
                        hideCover()
                    } else handler.postDelayed(this, 120)
                }
            }
        }
        readyPoll = poll; handler.post(poll)
    }
    private fun refreshPage() { showCover(true); ui.web.reload() }
    private fun goHome() {
        showCover(true); clearHistoryPending = true
        ui.web.evaluateJavascript("try{sessionStorage.clear()}catch(e){}", null)   // état temporaire du site ; la session (cookie) est conservée
        ui.web.loadUrl(BuildConfig.BASE_URL)
    }

    // ---------- Réglages natifs (appui long sur l'icône ▸ Réglages de l'application) ----------
    fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0) }
        col.addView(MaterialSwitch(this).apply { text = "Verrouillage empreinte / code"; isChecked = Prefs.lockEnabled(this@MainActivity); setOnCheckedChangeListener { _, v -> Prefs.setLock(this@MainActivity, v) } })
        MaterialAlertDialogBuilder(this).setTitle(R.string.settings).setView(col).setPositiveButton("Fermer", null).show()
    }

    // ---------- Divers ----------
    fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    fun openExternal(uri: Uri) {
        try {
            val u = if (uri.scheme == "intent") Uri.parse(Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).dataString) else uri
            startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) { toast("Application introuvable (WhatsApp installé ?)") }
        catch (e: Exception) { toast("Impossible d'ouvrir ce lien") }
    }
    private fun download(url: String, ua: String?, disposition: String?, mime: String?) {
        if (url.startsWith("blob:") || !url.startsWith("https")) return   // les blob: passent par AndroidBridge.saveAndOpen (voir INJECT_JS)
        val name = URLUtil.guessFileName(url, disposition, mime)
        val req = DownloadManager.Request(Uri.parse(url)).apply {
            setMimeType(mime); addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "IKA SO/$name")
        }
        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        Snackbar.make(ui.root, R.string.file_saved, Snackbar.LENGTH_SHORT).show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == ACTION_SETTINGS) ui.web.post { showSettings() }
        intent.data?.takeIf { it.host == host }?.let {      // retour de paiement, liens partagés : prioritaires sur le retour à l'accueil
            skipResetOnce = backgroundedAt > 0; showCover(true); ui.web.loadUrl(it.toString())
        }
    }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); ui.web.saveState(outState) }
    override fun onPause() { ui.web.onPause(); CookieManager.getInstance().flush(); super.onPause() }
    override fun onResume() { super.onResume(); ui.web.onResume() }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        netCallback?.let { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        ui.web.apply { stopLoading(); destroy() }; super.onDestroy()
    }

    companion object {
        const val ACTION_SETTINGS = "com.ikaso.app.OPEN_SETTINGS"
        const val RESET_AFTER_MS = 30_000L      // au-delà de 30 s hors de l'application : retour à l'accueil
        private const val MAX_WAIT_MS = 4_000L   // attente maximale du contenu avant de retirer le voile

        /** Vrai seulement si l'utilisateur a réellement tapé du texte, encore présent à l'écran et non envoyé. */
        private const val DIRTY_JS = "(function(){try{return !!(window.__ikaDirty&&window.__ikaDirty())}catch(e){return false}})()"

        /** Vrai quand la page est chargée, qu'aucune requête n'est en cours et que le contenu a eu le temps de s'afficher. */
        private const val READY_JS = "(function(){try{if(window.__ikaReady)return window.__ikaReady();return document.readyState==='complete'&&performance.now()>900}catch(e){return true}})()"

        /** Suit la saisie faite par l'utilisateur : texte tapé, liste ou case modifiée (événements « de confiance » uniquement : les valeurs posées par le site, comme « 0 », ne comptent pas). */
        private const val TRACK_JS = """
        (function(){
          if(window.__ikaTrack)return;window.__ikaTrack=true;
          var touched=[];
          var textSkip={hidden:1,file:1,checkbox:1,radio:1,range:1,color:1,submit:1,button:1,reset:1,image:1,search:1};
          function kind(f){
            var tg=f&&f.tagName,t=String(f&&f.type||'').toLowerCase();
            if(tg==='SELECT')return 'select';
            if(tg==='INPUT'&&(t==='checkbox'||t==='radio'))return 'check';
            if(tg==='TEXTAREA'||(tg==='INPUT'&&!textSkip[t]))return 'text';
            return '';
          }
          /* état de départ d'une liste / case, relevé juste avant que l'utilisateur la touche */
          function base(e){
            var f=e.target,k=kind(f);
            if((k==='select'||k==='check')&&f.__ikaBase===undefined)f.__ikaBase=(k==='select'?f.value:f.checked);
          }
          function mark(e){
            if(!e.isTrusted)return;
            var f=e.target;if(!kind(f))return;
            if(touched.indexOf(f)<0)touched.push(f);
          }
          ['touchstart','mousedown','focusin'].forEach(function(n){document.addEventListener(n,base,true)});
          document.addEventListener('input',mark,true);
          document.addEventListener('change',mark,true);
          document.addEventListener('submit',function(e){var fm=e.target;touched=touched.filter(function(f){return f.form!==fm})},true);
          window.__ikaDirty=function(){
            for(var i=0;i<touched.length;i++){var f=touched[i];
              if(!f.isConnected)continue;
              var k=kind(f);
              if(k==='text'){if(String(f.value||'').trim()!=='')return true}
              else if(k==='select'){if(f.__ikaBase!==undefined&&f.value!==f.__ikaBase)return true}
              else if(k==='check'){if(f.__ikaBase!==undefined&&f.checked!==f.__ikaBase)return true}
            }
            return false};
        })();"""

        /** Exécuté avant le site à chaque page : compte les requêtes réseau en cours (fetch / XHR) pour détecter la fin de l'affichage. */
        private const val DOC_START_JS = """
        (function(){
          if(window.__ikaBoot)return;window.__ikaBoot=true;
          var inflight=0,last=performance.now();
          function busy(){inflight++;last=performance.now()}
          function idle(){inflight=Math.max(0,inflight-1);last=performance.now()}
          var f=window.fetch;
          if(f){window.fetch=function(){busy();var p;try{p=f.apply(this,arguments)}catch(e){idle();throw e}
            return p.then(function(r){idle();return r},function(e){idle();throw e})}}
          var o=XMLHttpRequest.prototype.send;
          XMLHttpRequest.prototype.send=function(){busy();var d=false;
            this.addEventListener('loadend',function(){if(!d){d=true;idle()}});return o.apply(this,arguments)};
          window.__ikaReady=function(){return document.readyState==='complete'&&inflight===0&&performance.now()-last>350};
        })();"""

        /** Injecté après chaque chargement : zoom autorisé, images/tableaux contenus, et trois fonctions absentes de la WebView
         *  (impression, partage, ouverture de fichiers blob:) branchées sur Android. */
        private const val INJECT_JS = """
        (function(){
          if(window.__ikaInjected)return;window.__ikaInjected=true;
          var m=document.querySelector('meta[name=viewport]');
          if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m)}
          m.content='width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5, user-scalable=yes, viewport-fit=cover';
          var s=document.createElement('style');
          s.textContent='html{-webkit-text-size-adjust:100%;overscroll-behavior-y:contain}*{-webkit-tap-highlight-color:transparent}img,video{max-width:100%}table{max-width:100%}';
          document.head.appendChild(s);
          /* anti-actualisation accidentelle : pas de « tirer pour actualiser » dans un formulaire, un champ actif ou une zone déjà défilée */
          document.addEventListener('touchstart',function(e){var b=false;try{
            var m=document.getElementById('m');if(m&&m.innerHTML&&getComputedStyle(m).display!=='none')b=true;
            var a=document.activeElement;if(a&&/^(INPUT|TEXTAREA|SELECT)${'$'}/.test(a.tagName))b=true;
            for(var el=e.target;el&&el!==document.body&&!b;el=el.parentElement){if(el.scrollTop>0)b=true}
          }catch(x){}try{AndroidBridge.refreshBlocked(b)}catch(x){}},{capture:true,passive:true});
          window.print=function(){try{AndroidBridge.print(document.title||'Document')}catch(e){}};
          if(!navigator.share)navigator.share=function(d){try{AndroidBridge.shareText((d&&d.title)||'',(d&&d.text)||'',(d&&d.url)||'');return Promise.resolve()}catch(e){return Promise.reject(e)}};
          var wo=window.open;
          window.open=function(u,n,f){
            if(typeof u==='string'&&u.indexOf('blob:')===0){
              fetch(u).then(function(r){return r.blob()}).then(function(b){var fr=new FileReader();fr.onload=function(){
                var t=String(fr.result),i=t.indexOf(',');var ext=(b.type.split('/')[1]||'bin').split(';')[0].replace('jpeg','jpg');
                AndroidBridge.saveAndOpen('document.'+ext,b.type||'application/octet-stream',t.slice(i+1));};fr.readAsDataURL(b)});
              return null;
            }
            return wo.call(window,u,n,f);
          };
        })();"""
    }
}
